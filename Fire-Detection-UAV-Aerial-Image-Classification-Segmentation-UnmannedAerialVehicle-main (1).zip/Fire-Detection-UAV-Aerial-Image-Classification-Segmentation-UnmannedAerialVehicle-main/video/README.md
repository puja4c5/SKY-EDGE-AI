You can download and paste the videos here in this directory from the dataset repository [LINK](https://ieee-dataport.org/open-access/aerial-images-pile-fire-detection-using-drones-uavs).
