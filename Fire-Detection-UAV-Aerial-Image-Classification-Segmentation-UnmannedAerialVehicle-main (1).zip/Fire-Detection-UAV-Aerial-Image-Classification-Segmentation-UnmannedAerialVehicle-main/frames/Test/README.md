Please dowload item [8](https://ieee-dataport.org/open-access/aerial-images-pile-fire-detection-using-drones-uavs) from the repository and paste it here.
Then you can remove this README file and the direcotry should be like this:
```
Repository/frames/Test
                    ├── Fire/*.jpg
                    ├── No_Fire/*.jpg
```
